var require = meteorInstall({"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var Meteor = void 0;                                                 // 1
module.watch(require("meteor/meteor"), {                             // 1
  Meteor: function (v) {                                             // 1
    Meteor = v;                                                      // 1
  }                                                                  // 1
}, 0);                                                               // 1
var Mongo = void 0;                                                  // 1
module.watch(require("meteor/mongo"), {                              // 1
  "default": function (v) {                                          // 1
    Mongo = v;                                                       // 1
  }                                                                  // 1
}, 1);                                                               // 1
var Users = new Mongo.Colelction('users');                           // 4
Meteor.methods({                                                     // 6
  'getUsers': function () {                                          // 7
    return Mongo.find({}).fetch();                                   // 8
  }                                                                  // 9
});                                                                  // 6
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/main.js");
//# sourceMappingURL=app.js.map
